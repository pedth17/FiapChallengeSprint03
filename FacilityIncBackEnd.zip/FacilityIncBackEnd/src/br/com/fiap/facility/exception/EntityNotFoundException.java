package br.com.fiap.facility.exception;

public class EntityNotFoundException extends Exception {

	public EntityNotFoundException() {
		super("Entidade n�o foi encontrada!");
	}
	
	public EntityNotFoundException(String msg) {
		super(msg);
	}
}
