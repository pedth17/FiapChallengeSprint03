package br.com.fiap.facility.entity;

public enum Sexo {

	MACHO, FEMEA;
	
}
