package br.com.fiap.facility.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "T_MW_NOTIFICACO")
@SequenceGenerator(name = "notificacao", sequenceName = "SQ_T_MW_NOTIFICACAO")
public class Notificacao {

	@Id
	@Column(name = "id_notificacao")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notificacao")
	private int id;
	
	@Column(name = "ds_notificacao", length = 180)
	private String notificacao;

	@ManyToOne
	@JoinColumn(name = "id_dispositivo")
	private Dispositivo dispositivo;
	
	public Notificacao () {
		
	}
		
	public Notificacao(String notificacao, Dispositivo dispositivo) {
		super();
		this.notificacao = notificacao;
		this.dispositivo = dispositivo;
	}


	public Notificacao(int id, String notificacao, Dispositivo dispositivo) {
		super();
		this.id = id;
		this.notificacao = notificacao;
		this.dispositivo = dispositivo;
	}

	public Notificacao(int id, String notificacao) {
		super();
		this.id = id;
		this.notificacao = notificacao;
	}
	
	public Notificacao(String notificacao) {
		super();
		this.notificacao = notificacao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNotificacao() {
		return notificacao;
	}

	public void setNotificacao(String notificacao) {
		this.notificacao = notificacao;
	}

	public Dispositivo getDispositivo() {
		return dispositivo;
	}

	public void setDispositivo(Dispositivo dispositivo) {
		this.dispositivo = dispositivo;
	}
	
}
