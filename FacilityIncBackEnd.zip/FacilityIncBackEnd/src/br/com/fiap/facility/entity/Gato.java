package br.com.fiap.facility.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "T_MW_GATO")
@SequenceGenerator (name = "gato", sequenceName = "SQ_T_MW_GATO", allocationSize = 1)
public class Gato {

	@Id
	@Column(name = "id_gato")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gato")
	private int codigo;
	
	@Column(name = "nom_gato", nullable = false, length = 30)
	private String nome;
	
	@Column(name = "nom_raca", length = 30)
	private String raca;
	
	@Column(name = "val_peso", nullable = false)
	private Double peso;
	
	@Column(name = "nom_sexo")
	private Sexo sexo;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "dat_nascimento")
	private Calendar dataNascimento;
	
	@Column(name = "img_perfil_gato", length = 180)
	private String imagem;
	
	@ManyToOne
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;
	
	public Gato () {
		
	}
	
	public Gato(String nome, String raca, Double peso, Sexo sexo, Calendar dataNascimento, String imagem,
			Usuario usuario) {
		super();
		this.nome = nome;
		this.raca = raca;
		this.peso = peso;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.imagem = imagem;
		this.usuario = usuario;
	}

	public Gato(int codigo, String nome, String raca, Double peso, Sexo sexo, Calendar dataNascimento, String imagem,
			Usuario usuario) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.raca = raca;
		this.peso = peso;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.imagem = imagem;
		this.usuario = usuario;
	}

	public Gato(String nome, String raca, Double peso, Sexo sexo, Calendar dataNascimento, String imagem) {
		super();
		this.nome = nome;
		this.raca = raca;
		this.peso = peso;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.imagem = imagem;
	}

	public Gato(int codigo, String nome, String raca, Double peso, Sexo sexo, Calendar dataNascimento, String imagem) {
		this.codigo = codigo;
		this.nome = nome;
		this.raca = raca;
		this.peso = peso;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.imagem = imagem;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRaca() {
		return raca;
	}

	public void setRaca(String raca) {
		this.raca = raca;
	}

	public Double getPeso() {
		return peso;
	}

	public void setPeso(Double peso) {
		this.peso = peso;
	}

	public Calendar getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Calendar dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

	public Sexo getSexo() {
		return sexo;
	}

	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
}
