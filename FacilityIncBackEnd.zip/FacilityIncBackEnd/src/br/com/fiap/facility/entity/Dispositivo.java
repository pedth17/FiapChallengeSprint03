package br.com.fiap.facility.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "T_MW_DISPOSITIVO")
@SequenceGenerator(name = "dispositivo", sequenceName = "SQ_T_MW_DISPOSITIVO", allocationSize = 1)
public class Dispositivo {

	@Id
	@Column(name = "id_dispositivo")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dispositivo")
	private int id;
	
	@Column(name = "nom_dispositivo", nullable = false, length = 30)
	private String nome;
	
	@Column(name = "val_temperatura", nullable = false, length = 2)
	private String temperatura;
	
	@Column(name = "qtd_agua", nullable = false)
	private int quantidadeAgua;
	
	@Column(name = "qnt_ativacao_sensor", nullable = false)
	private int quantidadeAtivacao;

	@ManyToOne
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;
	
	@OneToMany(mappedBy = "dispositivo", cascade = CascadeType.MERGE)
	private List<Notificacao> notificacoes;
	
	public Dispositivo () {
		
	}
	
	public Dispositivo(String nome, String temperatura, int quantidadeAgua, int quantidadeAtivacao, Usuario usuario) {
		super();
		this.nome = nome;
		this.temperatura = temperatura;
		this.quantidadeAgua = quantidadeAgua;
		this.quantidadeAtivacao = quantidadeAtivacao;
		this.usuario = usuario;
	}

	public Dispositivo(int id, String nome, String temperatura, int quantidadeAgua, int quantidadeAtivacao,
			Usuario usuario) {
		super();
		this.id = id;
		this.nome = nome;
		this.temperatura = temperatura;
		this.quantidadeAgua = quantidadeAgua;
		this.quantidadeAtivacao = quantidadeAtivacao;
		this.usuario = usuario;
	}

	public Dispositivo(int id, String nome, String temperatura, int quantidadeAgua, int quantidadeAtivacao) {
		super();
		this.id = id;
		this.nome = nome;
		this.temperatura = temperatura;
		this.quantidadeAgua = quantidadeAgua;
		this.quantidadeAtivacao = quantidadeAtivacao;
	}
	
	public Dispositivo(String nome, String temperatura, int quantidadeAgua, int quantidadeAtivacao) {
		super();
		this.nome = nome;
		this.temperatura = temperatura;
		this.quantidadeAgua = quantidadeAgua;
		this.quantidadeAtivacao = quantidadeAtivacao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(String temperatura) {
		this.temperatura = temperatura;
	}

	public int getQuantidadeAgua() {
		return quantidadeAgua;
	}

	public void setQuantidadeAgua(int quantidadeAgua) {
		this.quantidadeAgua = quantidadeAgua;
	}

	public int getQuantidadeAtivacao() {
		return quantidadeAtivacao;
	}

	public void setQuantidadeAtivacao(int quantidadeAtivacao) {
		this.quantidadeAtivacao = quantidadeAtivacao;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public List<Notificacao> getNotificacoes() {
		return notificacoes;
	}

	public void setNotificacoes(List<Notificacao> notificacoes) {
		this.notificacoes = notificacoes;
	}
	
}
