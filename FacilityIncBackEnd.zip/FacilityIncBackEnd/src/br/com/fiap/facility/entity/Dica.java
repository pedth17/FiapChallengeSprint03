package br.com.fiap.facility.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "T_MW_DICA")
@SequenceGenerator(name = "dica", sequenceName = "SQ_T_MW_DICA", allocationSize = 1)
public class Dica {

	@Id
	@Column(name = "id_dica")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dica")
	private int id;
	
	@Column(name = "txt_dica", nullable = false, length = 255)
	private String dica;

	@OneToMany(mappedBy = "dica", cascade = CascadeType.MERGE)
	private List<DicaAtribuida> dicaAtribuida;
	
	public Dica () {
		
	}
	
	public Dica(int id, String dica) {
		super();
		this.id = id;
		this.dica = dica;
	}

	public Dica(String dica) {
		super();
		this.dica = dica;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDica() {
		return dica;
	}

	public void setDica(String dica) {
		this.dica = dica;
	}

	public List<DicaAtribuida> getDicaAtribuida() {
		return dicaAtribuida;
	}

	public void setDicaAtribuida(List<DicaAtribuida> dicaAtribuida) {
		this.dicaAtribuida = dicaAtribuida;
	}
	
	
}
