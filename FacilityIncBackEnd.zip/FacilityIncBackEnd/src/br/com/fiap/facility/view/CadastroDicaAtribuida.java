package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.DicaAtribuidaDao;
import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.DicaAtribuidaDaoImpl;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Dica;
import br.com.fiap.facility.entity.DicaAtribuida;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class CadastroDicaAtribuida {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Usuario, Integer> usuarioDao = new GenericDaoImpl<Usuario, Integer>(em){};
		GenericDao<Dica, Integer> dicaDao = new GenericDaoImpl<Dica, Integer>(em){};
		DicaAtribuidaDao dao = new DicaAtribuidaDaoImpl(em);
		
		try {
			DicaAtribuida dicaAtribuida1 = new DicaAtribuida (dicaDao.pesquisar(1), usuarioDao.pesquisar(1));
			DicaAtribuida dicaAtribuida2 = new DicaAtribuida (dicaDao.pesquisar(2), usuarioDao.pesquisar(2));
			DicaAtribuida dicaAtribuida3 = new DicaAtribuida (dicaDao.pesquisar(3), usuarioDao.pesquisar(3));
			DicaAtribuida dicaAtribuida4 = new DicaAtribuida (dicaDao.pesquisar(4), usuarioDao.pesquisar(4));
			DicaAtribuida dicaAtribuida5 = new DicaAtribuida (dicaDao.pesquisar(5), usuarioDao.pesquisar(5));
			dao.insert(dicaAtribuida1);
			dao.insert(dicaAtribuida2);
			dao.insert(dicaAtribuida3);
			dao.insert(dicaAtribuida4);
			dao.insert(dicaAtribuida5);
			dao.commit();
			System.out.println("Dicas Atribuidas Cadastradas !");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
		
	}
	
}
