package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.DicaAtribuidaDao;
import br.com.fiap.facility.dao.impl.DicaAtribuidaDaoImpl;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class ExcluirDicaAtribuida {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		DicaAtribuidaDao dao = new DicaAtribuidaDaoImpl(em);
		
		try {
			dao.pesquisar(5);
			dao.delete(5);
			dao.commit();
			System.out.println("Dica Atribuida Exclu�da!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
