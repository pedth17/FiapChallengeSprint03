package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GatoDao;
import br.com.fiap.facility.dao.impl.GatoDaoImpl;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class ExcluirGato {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GatoDao dao = new GatoDaoImpl(em);
		
		try {
			dao.pesquisar(1);
			dao.delete(1);
			dao.commit();
			System.out.println("Gato exclu�do!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
