package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.DicaDao;
import br.com.fiap.facility.dao.impl.DicaDaoImpl;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class ExcluirDica {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		DicaDao dao = new DicaDaoImpl(em);
		
		try {
			dao.pesquisar(1);
			dao.delete(1);
			dao.commit();
			System.out.println("Dica exclu�da!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
