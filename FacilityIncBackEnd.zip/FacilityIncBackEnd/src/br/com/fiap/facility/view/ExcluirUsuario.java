package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.UsuarioDao;
import br.com.fiap.facility.dao.impl.UsuarioDaoImpl;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class ExcluirUsuario {

	public static void main(String[] args) throws EntityNotFoundException, CommitException {
	
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		UsuarioDao dao = new UsuarioDaoImpl(em);
				
		try {
			dao.pesquisar(1);
			dao.delete(1);
			dao.commit();
			System.out.println("Usu�rio Excluido !");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
