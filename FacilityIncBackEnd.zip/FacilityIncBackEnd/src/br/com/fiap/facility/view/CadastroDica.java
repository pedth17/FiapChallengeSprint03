package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.DicaDao;
import br.com.fiap.facility.dao.impl.DicaDaoImpl;
import br.com.fiap.facility.entity.Dica;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class CadastroDica {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();

		DicaDao dao = new DicaDaoImpl(em);
		
		
		
		try {
			Dica dica1 = new Dica ("Mude o lugar de utiliza��o da MeoWater para um local mais aberto, "
					+ "mas n�o completamente ao ar livre, assim seu gato ter� mais facilidade e prazer de utiliza-la.");
			Dica dica2 = new Dica ("Sempre esteja atento as notifica��es enviadas ao aplicativo, elas podem ser de grande import�ncia"
					+ "para a sa�de de seu gato.");
			Dica dica3 = new Dica ("Verifique sempre se a fonte est� conectada a internet.");
			Dica dica4 = new Dica ("Fique ligado nas informa��es que forem enviadas pelo aplicativo com intuito de lhe informar sobre "
					+ "atualiza��es feitas !");
			Dica dica5 = new Dica ("Verifique se o local onde a fonte est� localizada fica constantemente ao sol, isso pode"
					+ "acabar aumentando drasticamente a temperatura da �gua la presente, o que a torna n�o perfeita para o consumo.");
			dao.insert(dica1);
			dao.insert(dica2);
			dao.insert(dica3);
			dao.insert(dica4);
			dao.insert(dica5);
			dao.commit();
			System.out.println("Dicas Cadastradas com sucesso!");
		} catch (CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
