package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.dao.DispositivoDao;
import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.DispositivoDaoImpl;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Dispositivo;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class CadastroDispositivo {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Usuario, Integer> usuarioDao = new GenericDaoImpl<Usuario, Integer>(em){};
		DispositivoDao dao = new DispositivoDaoImpl(em);
		
		try {
			Dispositivo dispositivo1 = new Dispositivo("MW Joao A. 1200", "14", 6110, 30, usuarioDao.pesquisar(1));
			Dispositivo dispositivo2 = new Dispositivo("Gabri3l JEOV 00Xl", "12", 5500, 22, usuarioDao.pesquisar(2));
			Dispositivo dispositivo3 = new Dispositivo("JL 3000", "15", 5200, 18, usuarioDao.pesquisar(3));
			Dispositivo dispositivo4 = new Dispositivo("Joao$antana Dell", "10", 7000, 25, usuarioDao.pesquisar(4));
			Dispositivo dispositivo5 = new Dispositivo("MW AquinoM 1300", "22", 6588, 50, usuarioDao.pesquisar(5));
			
			dao.insert(dispositivo1);
			dao.insert(dispositivo2);
			dao.insert(dispositivo3);
			dao.insert(dispositivo4);
			dao.insert(dispositivo5);
			
			dao.commit();
			System.out.println("Dispositivos cadastrado!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
