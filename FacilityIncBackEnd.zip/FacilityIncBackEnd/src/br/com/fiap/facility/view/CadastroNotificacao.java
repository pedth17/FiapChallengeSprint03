package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.NotificacaoDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.dao.impl.NotificacaoDaoImpl;
import br.com.fiap.facility.entity.Dispositivo;
import br.com.fiap.facility.entity.Notificacao;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class CadastroNotificacao {

		public static void main(String[] args) {
			
			EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
			
			GenericDao<Dispositivo, Integer> dispositivoDao = new GenericDaoImpl<Dispositivo, Integer>(em){};
			NotificacaoDao dao = new NotificacaoDaoImpl(em);
			
			try {
				Notificacao notificacao1 = new Notificacao("Aparelho quase vazio", dispositivoDao.pesquisar(1));
				Notificacao notificacao2 = new Notificacao("Aparelho cheio", dispositivoDao.pesquisar(2));
				Notificacao notificacao3 = new Notificacao("Aparelho fora de sintonia", dispositivoDao.pesquisar(3));
				Notificacao notificacao5 = new Notificacao("Aparelho com temperatura muito alta", dispositivoDao.pesquisar(5));
				Notificacao notificacao4 = new Notificacao("Aparelho quase vazio", dispositivoDao.pesquisar(4));
				dao.insert(notificacao1);
				dao.insert(notificacao2);
				dao.insert(notificacao3);
				dao.insert(notificacao4);
				dao.insert(notificacao5);
				dao.commit();
				System.out.println("Notificacao Cadastrada!");
			}catch(EntityNotFoundException | CommitException e) {
				System.out.println(e.getMessage());
			}
			em.close();
			EntityManagerFactorySingleton.getInstance().close();
		}
	
}
