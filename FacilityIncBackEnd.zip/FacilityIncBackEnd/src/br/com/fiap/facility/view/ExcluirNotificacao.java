package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.NotificacaoDao;
import br.com.fiap.facility.dao.impl.NotificacaoDaoImpl;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class ExcluirNotificacao {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		NotificacaoDao dao = new NotificacaoDaoImpl(em);
		
		try {
			dao.pesquisar(4);
			dao.delete(4);
			dao.commit();
			System.out.println("Notifica��o Exclu�da!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
