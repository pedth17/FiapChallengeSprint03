package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class AtualizarUsuario {

	public static void main(String[] args) throws EntityNotFoundException {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Usuario, Integer> dao = new GenericDaoImpl<Usuario, Integer>(em){};
				
		try {
			Usuario usuario1 = dao.pesquisar(1);
			usuario1.setNome("Pedro Henrique");
			usuario1.setEmail("pedth17@gmail.com");
			usuario1.setImagem("D:/meowater/perfil/imagens/usuarios/Phusuario1");
			dao.update(usuario1);
			dao.commit();
			System.out.println("Usuario Atualizado!");
		}catch(CommitException | EntityNotFoundException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
