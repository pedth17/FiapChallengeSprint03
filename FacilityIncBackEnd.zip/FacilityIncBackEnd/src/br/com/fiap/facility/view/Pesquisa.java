package br.com.fiap.facility.view;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.DicaAtribuidaDao;
import br.com.fiap.facility.dao.DicaDao;
import br.com.fiap.facility.dao.DispositivoDao;
import br.com.fiap.facility.dao.GatoDao;
import br.com.fiap.facility.dao.NotificacaoDao;
import br.com.fiap.facility.dao.UsuarioDao;
import br.com.fiap.facility.dao.impl.DicaAtribuidaDaoImpl;
import br.com.fiap.facility.dao.impl.DicaDaoImpl;
import br.com.fiap.facility.dao.impl.DispositivoDaoImpl;
import br.com.fiap.facility.dao.impl.GatoDaoImpl;
import br.com.fiap.facility.dao.impl.NotificacaoDaoImpl;
import br.com.fiap.facility.dao.impl.UsuarioDaoImpl;
import br.com.fiap.facility.entity.Dica;
import br.com.fiap.facility.entity.DicaAtribuida;
import br.com.fiap.facility.entity.Dispositivo;
import br.com.fiap.facility.entity.Gato;
import br.com.fiap.facility.entity.Notificacao;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

//Pesquisa simples para as entidades instanciadas
public class Pesquisa {
	
	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GatoDao gatoDao = new GatoDaoImpl(em);
		
		List<Gato> gatos = gatoDao.listar();
		
		System.out.println("Listagem de todos gatos:" + "\n");
		
		for (Gato gato : gatos) {
			System.out.println("Nome: " + gato.getNome() + " Ra�a: " + gato.getRaca() + " Peso: " + gato.getPeso() + "\n");
		}
		
		UsuarioDao usuarioDao = new UsuarioDaoImpl(em);
		
		List<Usuario> usuarios = usuarioDao.listar();	
		
		System.out.println("Listagem de todos usu�rios:" + "\n");
		
		for (Usuario usuario : usuarios) {
			System.out.println("Nome: " + usuario.getNome() + " Id: " + usuario.getId() + " E-mail: " + usuario.getEmail() + "\n");
		}
		
		DispositivoDao dispositivoDao = new DispositivoDaoImpl(em);
		
		List<Dispositivo> dispositivos = dispositivoDao.listar();
		
		System.out.println("Listagem de todos dispositivos: " + "\n");
		
		for (Dispositivo dispositivo : dispositivos) {
			System.out.println("Nome do dispositivo: " + dispositivo.getNome() + "\n");
		}
		
		DicaDao dicaDao = new DicaDaoImpl(em);
		
		List<Dica> dicas = dicaDao.listar();
		
		System.out.println("Listagem de todas dicas:" + "\n");
		
		for (Dica dica : dicas) {
			System.out.println("Id da dica: " + dica.getId() + " Descri��o da dica: " + dica.getDica() + "\n");
		}
		
		DicaAtribuidaDao dicaAtribuidaDao = new DicaAtribuidaDaoImpl(em);
		
		List<DicaAtribuida> dicasAtribuidas = dicaAtribuidaDao.listar();
		
		System.out.println("Listagem com o id's da DicaAtribuida: " + "\n");
		
		
		for (DicaAtribuida dicaAtribuida : dicasAtribuidas) {
			System.out.println("Id Dica Atribuida: " + dicaAtribuida.getId() + "\n");
		}
		
		NotificacaoDao notificacaoDao = new NotificacaoDaoImpl(em);
		
		List<Notificacao> notificacoes = notificacaoDao.listar();
		
		System.out.println("Listagem de notifica��es:" + "\n");
		
		for (Notificacao notificacao : notificacoes) {
			System.out.println("Id da notifica��o: " + notificacao.getId() + " Texto notifica��o: " + notificacao.getNotificacao());
		}
	}
	
}
