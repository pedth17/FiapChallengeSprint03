package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Dispositivo;
import br.com.fiap.facility.entity.Notificacao;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class AtualizarNotificacao {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Notificacao, Integer> notificacaoDao = new GenericDaoImpl<Notificacao, Integer>(em){};
		GenericDao<Dispositivo, Integer> dispositivoDao = new GenericDaoImpl<Dispositivo, Integer>(em){};
		
		try {
			Notificacao notificacao4 = notificacaoDao.pesquisar(4);
			notificacao4.setNotificacao("Aparelho necessita de manuten��o");
			notificacao4.setDispositivo(dispositivoDao.pesquisar(3));
			notificacaoDao.update(notificacao4);
			notificacaoDao.commit();
			System.out.println("Notifica��o Atualizada!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
