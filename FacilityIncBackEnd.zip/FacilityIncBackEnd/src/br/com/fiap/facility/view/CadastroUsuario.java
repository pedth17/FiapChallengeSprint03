package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.UsuarioDao;
import br.com.fiap.facility.dao.impl.UsuarioDaoImpl;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class CadastroUsuario {

	public static void main(String[] args) {
	
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		try {
			UsuarioDao dao = new UsuarioDaoImpl(em);
			
			Usuario usuario1 = new Usuario("Juscelino Alves Aquino Mendes", "jaMends08@hotmail.com.br", "VnKui80_1"
					, "D:/meowater/perfil/imagens/usuarios/usuario1");
			Usuario usuario2 = new Usuario("Gabriel Jeovani", "GabiJeovi08@gmail.com.br", "GoK_lvt21"
					, "D:/meowater/perfil/imagens/usuarios/usuario2");
			Usuario usuario3 = new Usuario("Jorgi Leonardo", "leoJorji@hotmail.com.br", "EHoLeo1234"
					, "D:/meowater/perfil/imagens/usuarios/usuario3");
			Usuario usuario4 = new Usuario("Jo�o Alberto Santana", "aprSantana@gmail.com.br", "jaS!2020"
					, "D:/meowater/perfil/imagens/usuarios/usuario4");
			Usuario usuario5 = new Usuario("Adalberta Aquino Mendes", "aquinOMendes08@hotmail.com.br", "VnKui80_2"
					, "D:/meowater/perfil/imagens/usuarios/usuario5");
			dao.insert(usuario1);
			dao.insert(usuario2);
			dao.insert(usuario3);
			dao.insert(usuario4);
			dao.insert(usuario5);
			dao.commit();
			System.out.println("Usuario Cadastrado!");
		}catch(CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
		
	}
}
