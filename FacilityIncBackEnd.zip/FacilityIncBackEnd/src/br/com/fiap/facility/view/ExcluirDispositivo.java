package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.DispositivoDao;
import br.com.fiap.facility.dao.impl.DispositivoDaoImpl;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class ExcluirDispositivo {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		DispositivoDao dao = new DispositivoDaoImpl(em);
		
		try {
			dao.pesquisar(1);
			dao.delete(1);
			dao.commit();
			System.out.println("Dispositivo Exclu�do!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
