package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Dica;
import br.com.fiap.facility.entity.DicaAtribuida;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class AtualizarDicaAtribuida {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<DicaAtribuida, Integer> dicaAtribuidaDao = new GenericDaoImpl<DicaAtribuida, Integer>(em){};
		GenericDao<Dica, Integer> dicaDao = new GenericDaoImpl<Dica, Integer>(em){};
		GenericDao<Usuario, Integer> usuarioDao = new GenericDaoImpl<Usuario, Integer>(em){};
		
		try {
			DicaAtribuida dicaAtribuida2 = dicaAtribuidaDao.pesquisar(2);
			dicaAtribuida2.setDica(dicaDao.pesquisar(3));
			dicaAtribuida2.setUsuario(usuarioDao.pesquisar(3));
			dicaAtribuidaDao.update(dicaAtribuida2);
			dicaAtribuidaDao.commit();
			System.out.println("Dica Atribuida atualizada!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
