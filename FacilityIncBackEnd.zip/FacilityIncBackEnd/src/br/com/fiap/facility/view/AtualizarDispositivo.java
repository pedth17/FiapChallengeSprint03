package br.com.fiap.facility.view; 

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Dispositivo;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class AtualizarDispositivo {

	public static void main(String[] args) {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Dispositivo, Integer> dispositivoDao = new GenericDaoImpl<Dispositivo, Integer>(em){};
				
		try {
			Dispositivo dispositivo1 = dispositivoDao.pesquisar(1);
			dispositivo1.setNome("MW Aquino A.M 2500");
			dispositivoDao.update(dispositivo1);
			dispositivoDao.commit();
			System.out.println("Dispositivo Atualizado!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
