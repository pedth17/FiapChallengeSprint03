package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Dica;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class AtualizarDica {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Dica, Integer> dicaDao = new GenericDaoImpl<Dica, Integer>(em){};
		
		try {
			Dica dica2 = dicaDao.pesquisar(2);
			dica2.setDica("Procure deixar a fonte em um lugar n�o muito alto, assim n�o ter� riscos do seu felino derruba-l�.");
			dicaDao.update(dica2);
			dicaDao.commit();
			System.out.println("Dica Atualizada!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
