package br.com.fiap.facility.view;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Gato;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class AtualizarGato {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GenericDao<Gato, Integer> gatoDao = new GenericDaoImpl<Gato, Integer>(em){};
		GenericDao<Usuario, Integer> usuarioDao = new GenericDaoImpl<Usuario, Integer>(em){}; //para caso o usuario (dono) mude possa ser atualizado
		
		try {
			Gato gato1 = gatoDao.pesquisar(1);
			gato1.setNome("Odin");
			gato1.setRaca("Siberiano");
			gato1.setPeso(6.20);
			gatoDao.update(gato1);
			gatoDao.commit();
			System.out.println("Gato Atualizado!");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
}
