package br.com.fiap.facility.view;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.EntityManager;

import br.com.fiap.facility.dao.GatoDao;
import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.dao.impl.GatoDaoImpl;
import br.com.fiap.facility.dao.impl.GenericDaoImpl;
import br.com.fiap.facility.entity.Gato;
import br.com.fiap.facility.entity.Sexo;
import br.com.fiap.facility.entity.Usuario;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;
import br.com.fiap.facility.singleton.EntityManagerFactorySingleton;

public class CadastroGato {

	public static void main(String[] args) {
		
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		
		GatoDao dao = new GatoDaoImpl(em);
		GenericDao<Usuario, Integer> usuarioDao = new GenericDaoImpl<Usuario, Integer>(em){};
		
		
		try {
			Gato gato1 = new Gato ("Zeus", "Angor�", 4.00, Sexo.MACHO,new GregorianCalendar(2021, Calendar.FEBRUARY, 04),
					"D:/meowater/perfil/imagens/gatos/gato1", usuarioDao.pesquisar(1));
			Gato gato2 = new Gato ("Poseidon", "Persian", 7.00, Sexo.MACHO,new GregorianCalendar(2020, Calendar.DECEMBER, 01),
					"D:/meowater/perfil/imagens/gatos/gato2", usuarioDao.pesquisar(2));
			Gato gato3 = new Gato ("Anastacio", "Siam�s", 3.50, Sexo.MACHO,new GregorianCalendar(2020, Calendar.FEBRUARY, 22),
					"D:/meowater/perfil/imagens/gatos/gato3", usuarioDao.pesquisar(3));
			Gato gato4 = new Gato ("Pandora", "SRD", 4.20, Sexo.FEMEA,new GregorianCalendar(2020, Calendar.MARCH, 20),
					"D:/meowater/perfil/imagens/gatos/gato4", usuarioDao.pesquisar(4));
			Gato gato5 = new Gato ("Fifi", "RagDoll", 5.00, Sexo.FEMEA,new GregorianCalendar(2021, Calendar.JANUARY, 10),
					"D:/meowater/perfil/imagens/gatos/gato5", usuarioDao.pesquisar(5));
			Gato gato6 = new Gato ("Athena", "SRD", 5.10, Sexo.FEMEA,new GregorianCalendar(2021, Calendar.OCTOBER, 30),
					"D:/meowater/perfil/imagens/gatos/gato6", usuarioDao.pesquisar(1)); //mesmo dono que o primeiro
			dao.insert(gato1);
			dao.insert(gato2);
			dao.insert(gato3);
			dao.insert(gato4);
			dao.insert(gato5);
			dao.insert(gato6);
			dao.commit();
			System.out.println("Gatos Cadastrados !");
		}catch(EntityNotFoundException | CommitException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		EntityManagerFactorySingleton.getInstance().close();
	}
	
}
