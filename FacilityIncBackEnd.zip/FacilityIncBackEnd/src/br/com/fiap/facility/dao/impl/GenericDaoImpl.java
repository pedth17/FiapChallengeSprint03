package br.com.fiap.facility.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.facility.dao.GenericDao;
import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;

public abstract class GenericDaoImpl <E,K> implements GenericDao <E,K>{

	protected EntityManager em;
	
	private Class<E> clazzz;
	
	@SuppressWarnings("unchecked")
	public GenericDaoImpl(EntityManager em) {
		this.em = em;
		clazzz = (Class<E>) ((ParameterizedType) 
				getClass().getGenericSuperclass())
						.getActualTypeArguments()[0];
	}
	
	@Override
	public void insert(E entidade) {
		em.persist(entidade);
	}
	
	@Override
	public void delete(K id) throws EntityNotFoundException {
		E entidade = pesquisar(id);
		if(entidade == null) {
			throw new EntityNotFoundException("Entidade n�o encontrada!");
		}
		em.remove(entidade);
	}
	
	@Override
	public E pesquisar (K id) throws EntityNotFoundException {
		E entidade = em.find(clazzz, id);
		if (entidade == null)
			throw new EntityNotFoundException();
		return entidade;
	}
	
	@Override
	public void update(E entidade) {
		em.merge(entidade);
	}

	@Override
	public void commit() throws CommitException {
		try {
			em.getTransaction().begin();
			em.getTransaction().commit();
		}catch (Exception e) {
			if(em.getTransaction().isActive())
			   em.getTransaction().rollback();
			e.printStackTrace();
			throw new CommitException("Erro no Commit");
		}
		
	}

	@Override
	public List<E> listar(){
		TypedQuery<E> query = em.createQuery("from " + clazzz.getName(), clazzz);
		query.setMaxResults(10);
		return query.getResultList();
		
	}
	
	@Override
	public List<E> listar(int primeiraPosicao, int numMaximoResultados){
		return em.createQuery("from " + clazzz.getName(), clazzz)
				.setMaxResults(numMaximoResultados)
				.setFirstResult(primeiraPosicao)
				.getResultList();
	}
	
}
