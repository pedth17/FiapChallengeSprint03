package br.com.fiap.facility.dao;

import java.util.List;

import br.com.fiap.facility.entity.Dispositivo;

public interface DispositivoDao extends GenericDao<Dispositivo, Integer>{

	List<Dispositivo> listar();
	
}
