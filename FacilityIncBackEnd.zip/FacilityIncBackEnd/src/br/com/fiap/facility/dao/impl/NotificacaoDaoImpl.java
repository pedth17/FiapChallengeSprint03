package br.com.fiap.facility.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.facility.dao.NotificacaoDao;
import br.com.fiap.facility.entity.Notificacao;

public class NotificacaoDaoImpl extends GenericDaoImpl<Notificacao, Integer> implements NotificacaoDao{

	public NotificacaoDaoImpl(EntityManager em) {
		super(em);
	}

	@Override
	public List<Notificacao> listar(){
		TypedQuery<Notificacao> query = em.createQuery("from Notificacao", Notificacao.class);
		return query.getResultList();
	}
	
}
