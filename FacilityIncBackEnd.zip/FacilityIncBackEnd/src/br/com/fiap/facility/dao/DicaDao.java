package br.com.fiap.facility.dao;

import java.util.List;

import br.com.fiap.facility.entity.Dica;

public interface DicaDao extends GenericDao<Dica, Integer>{

	List<Dica> listar();
	
}
