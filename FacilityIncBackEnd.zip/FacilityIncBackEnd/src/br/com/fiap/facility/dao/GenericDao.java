package br.com.fiap.facility.dao;

import java.util.List;

import br.com.fiap.facility.exception.CommitException;
import br.com.fiap.facility.exception.EntityNotFoundException;

public interface GenericDao<E,K>{
	
	void insert (E entidade);	
	
	void delete(K id) throws EntityNotFoundException;
	
	void update (E entidade);
	
	void commit() throws CommitException;

	E pesquisar(K id) throws EntityNotFoundException;
	
	//Listagem simples
	List<E> listar();
	
	//Listagem com pagina��o
	List<E> listar(int primeiraPosicao, int numMaximoResultados);
	
}
