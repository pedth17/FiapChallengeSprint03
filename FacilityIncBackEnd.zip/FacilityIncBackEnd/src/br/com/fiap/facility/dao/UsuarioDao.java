package br.com.fiap.facility.dao;

import java.util.List;

import br.com.fiap.facility.entity.Usuario;

public interface UsuarioDao extends GenericDao<Usuario, Integer>{

	List<Usuario> listar();
	
}
