package br.com.fiap.facility.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.facility.dao.DispositivoDao;
import br.com.fiap.facility.entity.Dispositivo;

public class DispositivoDaoImpl extends GenericDaoImpl<Dispositivo, Integer> implements DispositivoDao{

	public DispositivoDaoImpl(EntityManager em) {
		super(em);
	}

	@Override
	public List<Dispositivo> listar(){
		TypedQuery<Dispositivo> query = em.createQuery("from Dispositivo", Dispositivo.class);
		return query.getResultList();
	}
	
}
