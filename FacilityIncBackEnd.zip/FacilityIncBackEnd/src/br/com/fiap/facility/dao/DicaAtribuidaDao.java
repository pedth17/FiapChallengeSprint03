package br.com.fiap.facility.dao;

import java.util.List;

import br.com.fiap.facility.entity.DicaAtribuida;

public interface DicaAtribuidaDao extends GenericDao<DicaAtribuida, Integer>{

	List<DicaAtribuida> listar();
	
}
