package br.com.fiap.facility.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.facility.dao.GatoDao;
import br.com.fiap.facility.entity.Gato;

public class GatoDaoImpl extends GenericDaoImpl<Gato, Integer> implements GatoDao{

	public GatoDaoImpl(EntityManager em) {
		super(em);
	}

	@Override
	public List<Gato> listar(){
		TypedQuery<Gato> query = em.createQuery("from Gato", Gato.class);
		return query.getResultList();
		
	}
}
