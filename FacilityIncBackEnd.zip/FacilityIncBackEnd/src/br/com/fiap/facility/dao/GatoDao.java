package br.com.fiap.facility.dao;

import java.util.List;

import br.com.fiap.facility.entity.Gato;

public interface GatoDao extends GenericDao<Gato, Integer>{

	List<Gato> listar();
	
}
