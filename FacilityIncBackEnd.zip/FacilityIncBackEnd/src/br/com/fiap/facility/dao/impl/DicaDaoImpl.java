package br.com.fiap.facility.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.facility.dao.DicaDao;
import br.com.fiap.facility.entity.Dica;

public class DicaDaoImpl extends GenericDaoImpl<Dica, Integer> implements DicaDao{

	public DicaDaoImpl(EntityManager em) {
		super(em);
	}

	@Override
	public List<Dica> listar(){
		TypedQuery<Dica> query = em.createQuery("from Dica", Dica.class);
		return query.getResultList();
	}
	
}
