package br.com.fiap.facility.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.facility.dao.DicaAtribuidaDao;
import br.com.fiap.facility.entity.DicaAtribuida;

public class DicaAtribuidaDaoImpl extends GenericDaoImpl<DicaAtribuida, Integer> implements DicaAtribuidaDao{

	public DicaAtribuidaDaoImpl(EntityManager em) {
		super(em);
	}

	@Override
	public List<DicaAtribuida> listar(){
		TypedQuery<DicaAtribuida> query = em.createQuery("from DicaAtribuida", DicaAtribuida.class);
		return query.getResultList();
	}
	
}
